#!/usr/bin/env python

# TODO Make a class that is flexible and allows for easy gripper control
import rospy
from intera_interface import (
    Gripper,
    Lights,
    Cuff,
    RobotParams,
)



def main():
    rospy.init_node('my_gripper_node')




if __name__ == "__main__":
    pass